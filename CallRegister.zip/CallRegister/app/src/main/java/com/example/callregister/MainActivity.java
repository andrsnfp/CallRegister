package com.example.callregister;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CALL_LOG_PERMISSION = 1;
    private ListView callListView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> callList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        callListView = findViewById(R.id.callListView);
        callList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, callList);
        callListView.setAdapter(adapter);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALL_LOG}, REQUEST_CALL_LOG_PERMISSION);
        } else {
            loadCallLogs();
        }
    }

    private void loadCallLogs() {
        Cursor cursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                @SuppressLint("Range") int type = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.TYPE));
                @SuppressLint("Range") long dateMillis = cursor.getLong(cursor.getColumnIndex(CallLog.Calls.DATE)); // Obter data em milissegundos
                @SuppressLint("Range") int durationSeconds = cursor.getInt(cursor.getColumnIndex(CallLog.Calls.DURATION)); // Obter duração em segundos

                // Formatar a data
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
                String formattedDate = dateFormat.format(new Date(dateMillis));

                // Converter duração para horas, minutos e segundos
                String durationFormatted = formatDuration(durationSeconds);

                // Verificar o tipo de chamada
                String callType;

                switch (type) {
                    case CallLog.Calls.OUTGOING_TYPE:
                        callType = "Efetuada";
                        break;
                    case CallLog.Calls.INCOMING_TYPE:
                        callType = "Recebida";
                        break;
                    default:
                        callType = "Não Atendida";
                        break;
                }
                String callDetails;
                if(callType.equals("Não Atendida")){
                    callDetails = "Nª de telefone: " + number + "\nTipo: " + callType + "\nData: " + formattedDate;
                } else {
                    callDetails = "Nª de telefone: " + number + "\nTipo: " + callType + "\nData: " + formattedDate + "\nDuração: " + durationFormatted;
                }
                callList.add(callDetails);
            }
            cursor.close();
            adapter.notifyDataSetChanged();
        }
    }


    // Método para formatar a duração
    private String formatDuration(int seconds) {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int remainingSeconds = seconds % 60;

        // Formatar a string de duração
        StringBuilder durationBuilder = new StringBuilder();
        if (hours > 0) {
            durationBuilder.append(hours).append("h ");
        }
        if (minutes > 0 || hours > 0) { // Mostrar minutos se houver horas
            durationBuilder.append(minutes).append("m ");
        }
        durationBuilder.append(remainingSeconds).append("s");

        return durationBuilder.toString().trim();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL_LOG_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadCallLogs();
            } else {
                Toast.makeText(this, "Permission denied to read call logs", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
